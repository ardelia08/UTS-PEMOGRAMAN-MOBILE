import 'package:material_ui/material_ui.dart';
import 'screens/home_page.dart';

void main() {
  runApp(const CutakkApp());
}

class CutakkApp extends StatelessWidget {
  const CutakkApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CUTAKK',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF704632),
        ),
        scaffoldBackgroundColor: const Color(0xFFF5E9E2),
      ),
      home: const HomePage(),
    );
  }
}