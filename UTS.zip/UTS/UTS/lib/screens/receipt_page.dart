
import 'package:material_ui/material_ui.dart';
import '../models/menu.dart';

class ReceiptPage extends StatelessWidget {
  final List<Menu> menus;
  final Map<String, int> quantities;
  final int subtotal;
  final String paymentMethod;

  const ReceiptPage({
    super.key,
    required this.menus,
    required this.quantities,
    required this.subtotal,
    required this.paymentMethod,
  });

  static const Color background = Color(0xFFFAF6EF);
  static const Color beige = Color(0xFFEEE4D6);
  static const Color brown = Color(0xFF3D291F);
  static const Color muted = Color(0xFF876B59);

  String formatHarga(int harga) {
    final formatted = harga.toString().replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (match) => '.',
    );
    return 'Rp $formatted';
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();

    final tanggal =
        '${now.day.toString().padLeft(2, '0')}/'
        '${now.month.toString().padLeft(2, '0')}/'
        '${now.year}';

    final waktu =
        '${now.hour.toString().padLeft(2, '0')}:'
        '${now.minute.toString().padLeft(2, '0')}';

    final nomorTransaksi =
        'CTK${now.millisecondsSinceEpoch.toString().substring(6)}';

    return Scaffold(
      backgroundColor: background,
      appBar: AppBar(
        title: const Text(
          'Receipt',
          style: TextStyle(
            fontFamily: 'serif',
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: background,
        foregroundColor: brown,
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 12),

            const Icon(
              Icons.check_circle,
              size: 65,
              color: Color(0xFF6D8B62),
            ),

            const SizedBox(height: 12),

            const Text(
              'CUTAKK',
              style: TextStyle(
                fontSize: 27,
                fontWeight: FontWeight.bold,
                letterSpacing: 3,
                color: brown,
              ),
            ),

            const Text(
              'FOOD & BEVERAGE',
              style: TextStyle(
                fontSize: 9,
                letterSpacing: 2,
                color: muted,
              ),
            ),

            const SizedBox(height: 8),

            const Text(
              'Your order has been confirmed!',
              style: TextStyle(
                fontSize: 12,
                color: muted,
              ),
            ),

            const SizedBox(height: 22),

            // RECEIPT CARD
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Center(
                    child: Text(
                      'ORDER RECEIPT',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                        color: brown,
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  receiptRow('Order Number', nomorTransaksi),
                  receiptRow('Date', tanggal),
                  receiptRow('Time', waktu),
                  receiptRow('Payment Method', paymentMethod),

                  const Divider(
                    height: 30,
                    color: beige,
                    thickness: 1.2,
                  ),

                  const Text(
                    'Order Details',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: brown,
                    ),
                  ),

                  const SizedBox(height: 14),

                  ...menus.map((menu) {
                    final quantity =
                        quantities[menu.nama] ?? 0;

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 13),
                      child: Row(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              children: [
                                Text(
                                  menu.nama,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: brown,
                                  ),
                                ),
                                Text(
                                  '$quantity x ${formatHarga(menu.harga)}',
                                  style: const TextStyle(
                                    fontSize: 10,
                                    color: muted,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Text(
                            formatHarga(menu.harga * quantity),
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: brown,
                            ),
                          ),
                        ],
                      ),
                    );
                  }),

                  const Divider(
                    height: 25,
                    color: beige,
                  ),

                  receiptRow('Subtotal', formatHarga(subtotal)),

                  const SizedBox(height: 12),

                  Container(
                    padding: const EdgeInsets.all(13),
                    decoration: BoxDecoration(
                      color: beige,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment:
                          MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'TOTAL',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: brown,
                          ),
                        ),
                        Text(
                          formatHarga(subtotal),
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: brown,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 18),

                  const Center(
                    child: Column(
                      children: [
                        Text(
                          'Pesanan dikonfirmasi',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: brown,
                          ),
                        ),
                        SizedBox(height: 5),
                        Text(
                          'Terima kasih telah memesan di CUTAKK.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 10,
                            color: muted,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 18),

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: beige,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                'Catatan: Bukti pesanan ini merupakan simulasi '
                'transaksi untuk aplikasi praktikum CUTAKK.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 10,
                  color: muted,
                  height: 1.5,
                ),
              ),
            ),

            const SizedBox(height: 22),

            SizedBox(
              width: double.infinity,
              height: 50,
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: brown,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(13),
                  ),
                ),
                onPressed: () {
                  Navigator.pop(context, true);
                },
                child: const Text(
                  'Selesai',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Widget receiptRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 11,
                color: muted,
              ),
            ),
          ),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: brown,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
