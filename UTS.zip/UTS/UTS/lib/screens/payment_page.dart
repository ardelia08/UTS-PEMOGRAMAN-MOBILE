import 'package:material_ui/material_ui.dart';

import '../models/menu.dart';
import 'receipt_page.dart';

class PaymentPage extends StatefulWidget {
  final List<Menu> menus;
  final Map<String, int> quantities;
  final int subtotal;

  const PaymentPage({
    super.key,
    required this.menus,
    required this.quantities,
    required this.subtotal,
  });

  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  static const Color background = Color(0xFFFAF6EF);
  static const Color beige = Color(0xFFEEE4D6);
  static const Color brown = Color(0xFF3D291F);
  static const Color muted = Color(0xFF876B59);

  String selectedPayment = 'Cash';

  String formatHarga(int harga) {
    final formatted = harga.toString().replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (match) => '.',
    );

    return 'Rp $formatted';
  }

  Widget paymentOption({
    required String title,
    required String description,
    required IconData icon,
  }) {
    final selected = selectedPayment == title;

    return InkWell(
      onTap: () {
        setState(() {
          selectedPayment = title;
        });
      },
      borderRadius: BorderRadius.circular(14),
      child: Container(
        margin: const EdgeInsets.only(bottom: 11),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? beige : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? brown : Colors.transparent,
            width: 1.2,
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: brown, size: 25),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: brown,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: const TextStyle(color: muted, fontSize: 10),
                  ),
                ],
              ),
            ),
            Icon(
              selected ? Icons.radio_button_checked : Icons.radio_button_off,
              color: selected ? brown : muted,
            ),
          ],
        ),
      ),
    );
  }

  // Membuka halaman struk dan mengembalikan metode pembayaran
  // setelah halaman struk selesai dikonfirmasi.
  Future<void> _confirmOrder() async {
    final confirmed = await Navigator.of(context).push<bool>(
      MaterialPageRoute<bool>(
        builder: (_) => ReceiptPage(
          menus: widget.menus,
          quantities: widget.quantities,
          subtotal: widget.subtotal,
          paymentMethod: selectedPayment,
        ),
      ),
    );

    // Karena fungsi ini memakai State.context, periksa State.mounted
    // sebelum menggunakan context kembali setelah proses async.
    if (!mounted) return;

    if (confirmed == true) {
      Navigator.of(context).pop(selectedPayment);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      appBar: AppBar(
        backgroundColor: background,
        foregroundColor: brown,
        elevation: 0,
        title: const Text(
          'Payment',
          style: TextStyle(fontFamily: 'serif', fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Order Summary',
              style: TextStyle(
                fontSize: 20,
                fontFamily: 'serif',
                fontWeight: FontWeight.bold,
                color: brown,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Periksa kembali pesananmu sebelum membayar.',
              style: TextStyle(color: muted, fontSize: 11),
            ),
            const SizedBox(height: 18),

            // DAFTAR PESANAN
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  ...widget.menus.map((menu) {
                    final quantity = widget.quantities[menu.nama] ?? 0;

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 13),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              '${menu.nama} x$quantity',
                              style: const TextStyle(
                                fontSize: 12,
                                color: brown,
                              ),
                            ),
                          ),
                          Text(
                            formatHarga(menu.harga * quantity),
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: brown,
                            ),
                          ),
                        ],
                      ),
                    );
                  }),
                  const Divider(color: beige),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Subtotal',
                        style: TextStyle(color: muted, fontSize: 12),
                      ),
                      Text(
                        formatHarga(widget.subtotal),
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: brown,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Total Pembayaran',
                        style: TextStyle(
                          color: brown,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        formatHarga(widget.subtotal),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: brown,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 25),
            const Text(
              'Payment Method',
              style: TextStyle(
                fontSize: 20,
                fontFamily: 'serif',
                fontWeight: FontWeight.bold,
                color: brown,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Pilih metode pembayaran yang kamu inginkan.',
              style: TextStyle(color: muted, fontSize: 11),
            ),
            const SizedBox(height: 16),

            // PILIHAN METODE PEMBAYARAN
            paymentOption(
              title: 'Cash',
              description: 'Bayar langsung saat pengambilan.',
              icon: Icons.payments_outlined,
            ),
            paymentOption(
              title: 'QRIS',
              description: 'Pembayaran melalui kode QR.',
              icon: Icons.qr_code_2,
            ),
            paymentOption(
              title: 'Transfer Bank',
              description: 'Pembayaran melalui rekening bank.',
              icon: Icons.account_balance_outlined,
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(13),
              decoration: BoxDecoration(
                color: beige,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline, color: brown, size: 17),
                  SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      'Pilihan pembayaran ini merupakan simulasi '
                      'untuk aplikasi CUTAKK dan belum terhubung '
                      'dengan layanan pembayaran sungguhan.',
                      style: TextStyle(color: muted, fontSize: 10, height: 1.5),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 15),
          color: Colors.white,
          child: SizedBox(
            height: 50,
            width: double.infinity,
            child: FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: brown,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(13),
                ),
              ),
              onPressed: _confirmOrder,
              child: const Text(
                'Konfirmasi Pesanan',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
