
import 'package:material_ui/material_ui.dart';

class ProfilePage extends StatelessWidget {
  final VoidCallback onFavoritesTap;

  const ProfilePage({
    super.key,
    required this.onFavoritesTap,
  });

  static const Color background = Color(0xFFFAF6EF);
  static const Color beige = Color(0xFFEEE4D6);
  static const Color brown = Color(0xFF3D291F);
  static const Color muted = Color(0xFF876B59);

  Widget profileOption({
    required IconData icon,
    required String title,
    required String subtitle,
    VoidCallback? onTap,
  }) {
    return Card(
      color: Colors.white,
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
      ),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 15,
          vertical: 4,
        ),
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: beige,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: brown,
            size: 20,
          ),
        ),
        title: Text(
          title,
          style: const TextStyle(
            color: brown,
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: const TextStyle(
            color: muted,
            fontSize: 10,
          ),
        ),
        trailing: const Icon(
          Icons.chevron_right,
          color: muted,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 25),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'My Profile',
            style: TextStyle(
              fontSize: 25,
              fontWeight: FontWeight.w600,
              fontFamily: 'serif',
              color: brown,
            ),
          ),

          const SizedBox(height: 6),

          const Text(
            'Manage your CUTAKK account.',
            style: TextStyle(
              fontSize: 12,
              color: muted,
            ),
          ),

          const SizedBox(height: 25),

          // PROFILE CARD
            Container(
            width: 104,
            height: 104,
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                border: Border.all(
                color: beige,
                width: 1,
                ),
            ),
            clipBehavior: Clip.antiAlias,
            child: Image.asset(
                'assets/menu/logo.jpeg',
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                return const Icon(
                    Icons.restaurant,
                    size: 45,
                    color: brown,
                );
                },
            ),
            ),


          const SizedBox(height: 27),

          const Text(
            'Account',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'serif',
              color: brown,
            ),
          ),

          const SizedBox(height: 13),

          profileOption(
            icon: Icons.favorite_border,
            title: 'My Favorites',
            subtitle: 'Lihat menu yang kamu sukai',
            onTap: onFavoritesTap,
          ),

          profileOption(
            icon: Icons.restaurant_menu,
            title: 'Our Menu',
            subtitle: 'Jelajahi koleksi makanan dan minuman',
          ),

          const SizedBox(height: 18),

          const Text(
            'About Application',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'serif',
              color: brown,
            ),
          ),

          const SizedBox(height: 13),

          profileOption(
            icon: Icons.info_outline,
            title: 'About CUTAKK',
            subtitle: 'Informasi tentang aplikasi CUTAKK',
            onTap: () {
              showAboutDialog(
                context: context,
                applicationName: 'CUTAKK',
                applicationVersion: '1.0.0',
                applicationLegalese:
                    'Food & Beverage Catalog Application',
              );
            },
          ),

          profileOption(
            icon: Icons.help_outline,
            title: 'Help & Support',
            subtitle: 'Bantuan penggunaan aplikasi',
            onTap: () {
              showDialog(
                context: context,
                builder: (context) {
                  return AlertDialog(
                    backgroundColor: background,
                    title: const Text(
                      'Help & Support',
                      style: TextStyle(color: brown),
                    ),
                    content: const Text(
                      'CUTAKK merupakan aplikasi katalog '
                      'makanan dan minuman untuk memudahkan '
                      'pengguna melihat menu dan membuat pesanan.',
                      style: TextStyle(
                        color: muted,
                        height: 1.5,
                      ),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: const Text(
                          'Tutup',
                          style: TextStyle(color: brown),
                        ),
                      ),
                    ],
                  );
                },
              );
            },
          ),

          const SizedBox(height: 20),

          const Center(
            child: Column(
              children: [
                Text(
                  'CUTAKK',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 3,
                    color: brown,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Good Food, Great Mood',
                  style: TextStyle(
                    fontSize: 10,
                    color: muted,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  'Version 1.0.0',
                  style: TextStyle(
                    fontSize: 9,
                    color: muted,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
