
import 'package:material_ui/material_ui.dart';
import '../models/menu.dart';

class MenuDetailPage extends StatefulWidget {
  final Menu menu;
  final bool isFavorite;
  final VoidCallback onToggleFavorite;
  final ValueChanged<int> onAddToCart;

  const MenuDetailPage({
    super.key,
    required this.menu,
    required this.isFavorite,
    required this.onToggleFavorite,
    required this.onAddToCart,
  });

  @override
  State<MenuDetailPage> createState() => _MenuDetailPageState();
}

class _MenuDetailPageState extends State<MenuDetailPage> {
  static const Color background = Color(0xFFFAF6EF);
  static const Color beige = Color(0xFFEEE4D6);
  static const Color brown = Color(0xFF3D291F);
  static const Color muted = Color(0xFF876B59);

  late bool isFavorite;
  int quantity = 1;

  @override
  void initState() {
    super.initState();
    isFavorite = widget.isFavorite;
  }

  String formatHarga(int harga) {
    if (harga == 0) return 'Harga menyusul';

    final value = harga.toString().replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (match) => '.',
    );

    return 'Rp $value';
  }

  String get totalHarga {
    if (widget.menu.harga == 0) {
      return 'Harga menyusul';
    }

    return formatHarga(widget.menu.harga * quantity);
  }

  Widget quantityButton(IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: beige,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(
          icon,
          size: 17,
          color: brown,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final menu = widget.menu;

    return Scaffold(
      backgroundColor: background,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 15, 20, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // HEADER
                    Row(
                      children: [
                        IconButton(
                          onPressed: () => Navigator.pop(context),
                          icon: const Icon(
                            Icons.arrow_back,
                            color: brown,
                          ),
                        ),
                        const SizedBox(width: 5),
                        const Text(
                          'Detail menu',
                          style: TextStyle(
                            fontSize: 15,
                            color: brown,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 15),

                    // FOTO PRODUK
                    Stack(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Image.asset(
                            menu.gambar,
                            width: double.infinity,
                            height: 205,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              return Container(
                                height: 205,
                                width: double.infinity,
                                color: beige,
                                child: const Center(
                                  child: Icon(
                                    Icons.restaurant,
                                    size: 55,
                                    color: muted,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),

                        Positioned(
                          top: 12,
                          right: 12,
                          child: Material(
                            color: Colors.white,
                            shape: const CircleBorder(),
                            child: IconButton(
                              onPressed: () {
                                setState(() {
                                  isFavorite = !isFavorite;
                                });
                                widget.onToggleFavorite();
                              },
                              icon: Icon(
                                isFavorite
                                    ? Icons.favorite
                                    : Icons.favorite_border,
                                color: isFavorite ? Colors.red : brown,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 20),

                    // KATEGORI
                    Text(
                      menu.kategori.toUpperCase(),
                      style: const TextStyle(
                        fontSize: 10,
                        letterSpacing: 1,
                        color: muted,
                        fontWeight: FontWeight.w600,
                      ),
                    ),

                    const SizedBox(height: 6),

                    // NAMA MENU
                    Text(
                      menu.nama,
                      style: const TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'serif',
                        color: brown,
                      ),
                    ),

                    const SizedBox(height: 7),

                    // HARGA
                    Text(
                      formatHarga(menu.harga),
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        color: brown,
                      ),
                    ),

                    const SizedBox(height: 12),

                    // DESKRIPSI
                    Text(
                      menu.deskripsi,
                      style: const TextStyle(
                        fontSize: 12,
                        height: 1.6,
                        color: muted,
                      ),
                    ),

                    const SizedBox(height: 18),

                    // INFORMASI PRODUK
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: beige,
                        borderRadius: BorderRadius.circular(13),
                      ),
                      child: const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Freshly made, just for you.',
                            style: TextStyle(
                              fontSize: 14,
                              fontFamily: 'serif',
                              fontWeight: FontWeight.w600,
                              color: brown,
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            'Disiapkan setelah kamu memesan. '
                            'Nikmati setiap hidangan bersama '
                            'kopi favoritmu.',
                            style: TextStyle(
                              fontSize: 10,
                              height: 1.5,
                              color: muted,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 23),

                    // QUANTITY DAN TOTAL
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Jumlah menu',
                              style: TextStyle(
                                fontSize: 10,
                                color: muted,
                              ),
                            ),
                            const SizedBox(height: 7),
                            Row(
                              children: [
                                quantityButton(
                                  Icons.remove,
                                  () {
                                    if (quantity > 1) {
                                      setState(() {
                                        quantity--;
                                      });
                                    }
                                  },
                                ),
                                SizedBox(
                                  width: 34,
                                  child: Text(
                                    '$quantity',
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: brown,
                                    ),
                                  ),
                                ),
                                quantityButton(
                                  Icons.add,
                                  () {
                                    setState(() {
                                      quantity++;
                                    });
                                  },
                                ),
                              ],
                            ),
                          ],
                        ),

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            const Text(
                              'Total harga',
                              style: TextStyle(
                                fontSize: 10,
                                color: muted,
                              ),
                            ),
                            const SizedBox(height: 7),
                            Text(
                              totalHarga,
                              style: const TextStyle(
                                fontSize: 19,
                                fontWeight: FontWeight.bold,
                                color: brown,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            // ADD TO CART
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 15),
              child: SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: brown,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(13),
                    ),
                  ),
                  onPressed: () {
                    widget.onAddToCart(quantity);
                    Navigator.pop(context);
                  },
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Add to Cart',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Icon(Icons.arrow_forward, size: 19),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
