import 'package:material_ui/material_ui.dart';

import 'menu_detail_page.dart';
import 'payment_page.dart';
import 'profile_page.dart';

import '../data/menu_data.dart';
import '../models/menu.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const Color background = Color(0xFFFAF6EF);
  static const Color beige = Color(0xFFEEE4D6);
  static const Color brown = Color(0xFF3D291F);
  static const Color muted = Color(0xFF876B59);

  final TextEditingController _searchController = TextEditingController();

  final List<String> categories = ['All', 'Makanan', 'Minuman', 'Dessert'];

  String selectedCategory = 'All';
  String searchQuery = '';
  int selectedNavIndex = 0;

  final Set<String> favorites = {};
  final Map<String, int> cart = {};

  // JUMLAH SELURUH MENU DI KERANJANG
  int get cartCount {
    return cart.values.fold(0, (total, value) => total + value);
  }

  // DAFTAR MENU YANG ADA DI KERANJANG
  List<Menu> get cartMenus {
    return daftarMenu.where((menu) {
      return (cart[menu.nama] ?? 0) > 0;
    }).toList();
  }

  // TOTAL HARGA KERANJANG
  int get cartSubtotal {
    return cartMenus.fold(0, (total, menu) {
      return total + (menu.harga * (cart[menu.nama] ?? 0));
    });
  }

  // MEMERIKSA HARGA MENU
  bool get hasUnpricedItems {
    return cartMenus.any((menu) => menu.harga <= 0);
  }

  void updateCartQuantity(Menu menu, int change) {
    setState(() {
      final newQuantity = (cart[menu.nama] ?? 0) + change;

      if (newQuantity <= 0) {
        cart.remove(menu.nama);
      } else {
        cart[menu.nama] = newQuantity;
      }
    });
  }

  Future<void> goToPayment() async {
    if (cartMenus.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Keranjang masih kosong.')));
      return;
    }

    if (hasUnpricedItems) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Lengkapi harga semua menu terlebih dahulu.'),
        ),
      );
      return;
    }

    final selectedMethod = await Navigator.of(context).push<String>(
      MaterialPageRoute<String>(
        builder: (_) => PaymentPage(
          menus: cartMenus,
          quantities: Map<String, int>.from(cart),
          subtotal: cartSubtotal,
        ),
      ),
    );

    if (!mounted || selectedMethod == null) return;
    setState(() {
      cart.clear();
      selectedNavIndex = 0;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Metode pembayaran dipilih: $selectedMethod'),
        backgroundColor: brown,
      ),
    );
  }

  List<Menu> get filteredMenus {
    return daftarMenu.where((menu) {
      final category = menu.kategori.toLowerCase();

      final categoryMatch =
          selectedCategory == 'All' ||
          category == selectedCategory.toLowerCase() ||
          (selectedCategory == 'Dessert' &&
              (category.contains('dessert') || category.contains('pastry')));

      final searchMatch = menu.nama.toLowerCase().contains(
        searchQuery.toLowerCase(),
      );

      final favoriteMatch =
          selectedNavIndex != 1 || favorites.contains(menu.nama);

      return categoryMatch && searchMatch && favoriteMatch;
    }).toList();
  }

  String formatHarga(int harga) {
    if (harga == 0) return 'Harga menyusul';

    final formatted = harga.toString().replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (match) => '.',
    );

    return 'Rp $formatted';
  }

  String displayCategory(Menu menu) {
    if (menu.kategori.toLowerCase().contains('dessert') ||
        menu.kategori.toLowerCase().contains('pastry')) {
      return 'Dessert';
    }
    return menu.kategori;
  }

  void toggleFavorite(Menu menu) {
    setState(() {
      if (favorites.contains(menu.nama)) {
        favorites.remove(menu.nama);
      } else {
        favorites.add(menu.nama);
      }
    });
  }

  void addToCart(Menu menu, [int quantity = 1]) {
    setState(() {
      cart[menu.nama] = (cart[menu.nama] ?? 0) + quantity;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${menu.nama} sebanyak $quantity berhasil ditambahkan'),
        backgroundColor: brown,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 1),
      ),
    );
  }

  void showMenuDetail(Menu menu) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MenuDetailPage(
          menu: menu,
          isFavorite: favorites.contains(menu.nama),
          onToggleFavorite: () => toggleFavorite(menu),
          onAddToCart: (quantity) {
            addToCart(menu, quantity);
          },
        ),
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: SafeArea(
        child: selectedNavIndex == 0 || selectedNavIndex == 1
            ? buildDashboard()
            : selectedNavIndex == 2
            ? buildCartPage()
            : selectedNavIndex == 3
            ? ProfilePage(
                onFavoritesTap: () {
                  setState(() {
                    selectedNavIndex = 1;
                  });
                },
              )
            : buildDashboard(),
      ),
      bottomNavigationBar: buildBottomNavigation(),
    );
  }

  Widget buildDashboard() {
    final isFavoritePage = selectedNavIndex == 1;

    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        // HEADER, BANNER, DAN SEARCH
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // HEADER LOGO
                Row(
                  children: [
                    Container(
                      width: 54,
                      height: 54,
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        border: Border.all(color: beige),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: Image.asset(
                        'assets/menu/logo.jpeg',
                        fit: BoxFit.contain,
                        errorBuilder: (context, error, stackTrace) {
                          return const Icon(Icons.restaurant, color: brown);
                        },
                      ),
                    ),

                    const SizedBox(width: 12),

                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Selamat pagi,',
                            style: TextStyle(fontSize: 11, color: muted),
                          ),
                          FittedBox(
                            fit: BoxFit.scaleDown,
                            alignment: Alignment.centerLeft,
                            child: Text(
                              isFavoritePage
                                  ? 'Your little favorites.'
                                  : 'Mau pesan apa hari ini?',
                              maxLines: 1,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                                color: brown,
                                fontFamily: 'serif',
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(width: 8),

                    CircleAvatar(
                      radius: 24,
                      backgroundColor: beige,
                      child: IconButton(
                        onPressed: () {
                          setState(() {
                            selectedNavIndex = 3;
                          });
                        },
                        icon: const Icon(
                          Icons.person_outline,
                          color: brown,
                          size: 21,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 14),

                // PROMO BANNER
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 14,
                  ),
                  decoration: BoxDecoration(
                    color: beige,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'A LITTLE BREAK, A BETTER DAY.',
                        style: TextStyle(
                          fontSize: 8,
                          letterSpacing: 1,
                          color: muted,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        'Your daily dose of happiness.',
                        style: TextStyle(
                          fontSize: 19,
                          height: 1.1,
                          color: brown,
                          fontFamily: 'serif',
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                // SEARCH BAR
                TextField(
                  controller: _searchController,
                  onChanged: (value) {
                    setState(() {
                      searchQuery = value;
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'Cari menu favoritmu...',
                    hintStyle: const TextStyle(fontSize: 12, color: muted),
                    prefixIcon: const Icon(
                      Icons.search,
                      size: 19,
                      color: muted,
                    ),
                    suffixIcon: searchQuery.isNotEmpty
                        ? IconButton(
                            onPressed: () {
                              _searchController.clear();
                              setState(() {
                                searchQuery = '';
                              });
                            },
                            icon: const Icon(Icons.close, size: 18),
                          )
                        : null,
                    filled: true,
                    fillColor: Colors.white,
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(vertical: 12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),

        // STICKY CATEGORY NAVBAR
        SliverPersistentHeader(
          pinned: true,
          delegate: CategoryHeaderDelegate(
            categories: categories,
            selectedCategory: selectedCategory,
            background: background,
            beige: beige,
            brown: brown,
            onCategorySelected: (category) {
              setState(() {
                selectedCategory = category;
              });
            },
          ),
        ),

        // JUDUL MENU
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  isFavoritePage ? 'Menu favoritmu' : 'Pilihan untukmu',
                  style: const TextStyle(
                    fontFamily: 'serif',
                    fontSize: 19,
                    fontWeight: FontWeight.w600,
                    color: brown,
                  ),
                ),
                Text(
                  '${filteredMenus.length} menu',
                  style: const TextStyle(fontSize: 10, color: muted),
                ),
              ],
            ),
          ),
        ),

        // DAFTAR MENU DINAMIS
        if (filteredMenus.isEmpty)
          SliverFillRemaining(
            hasScrollBody: false,
            child: Center(
              child: Text(
                isFavoritePage
                    ? 'Belum ada menu favorit.'
                    : 'Menu tidak ditemukan.',
                style: const TextStyle(color: muted),
              ),
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 20),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate((context, index) {
                final menu = filteredMenus[index];
                return buildMenuCard(menu);
              }, childCount: filteredMenus.length),
              gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                maxCrossAxisExtent: 210,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                mainAxisExtent: 225,
              ),
            ),
          ),
      ],
    );
  }

  Widget buildMenuCard(Menu menu) {
    final isFavorite = favorites.contains(menu.nama);

    return Card(
      margin: EdgeInsets.zero,
      color: Colors.white,
      elevation: 1,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // GAMBAR PRODUK
          Stack(
            children: [
              InkWell(
                onTap: () => showMenuDetail(menu),
                child: SizedBox(
                  height: 132,
                  width: double.infinity,
                  child: Image.asset(
                    menu.gambar,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        color: beige,
                        child: const Center(
                          child: Icon(Icons.restaurant, size: 38, color: muted),
                        ),
                      );
                    },
                  ),
                ),
              ),

              // FAVORITE BUTTON
              Positioned(
                top: 8,
                right: 8,
                child: Material(
                  color: Colors.white,
                  shape: const CircleBorder(),
                  child: InkWell(
                    customBorder: const CircleBorder(),
                    onTap: () => toggleFavorite(menu),
                    child: SizedBox(
                      width: 32,
                      height: 32,
                      child: Icon(
                        isFavorite ? Icons.favorite : Icons.favorite_border,
                        color: isFavorite ? Colors.red : brown,
                        size: 17,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),

          // INFORMASI MENU
          SizedBox(
            height: 90,
            child: ListTile(
              dense: true,
              visualDensity: const VisualDensity(horizontal: -3, vertical: -4),
              contentPadding: const EdgeInsets.only(left: 9, right: 5),
              title: Text(
                menu.nama,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: brown,
                ),
              ),
              subtitle: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    displayCategory(menu),
                    style: const TextStyle(fontSize: 10, color: muted),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    formatHarga(menu.harga),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: brown,
                    ),
                  ),
                ],
              ),
              trailing: IconButton(
                tooltip: 'Tambah ke keranjang',
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints.tightFor(
                  width: 30,
                  height: 30,
                ),
                style: IconButton.styleFrom(
                  backgroundColor: brown,
                  foregroundColor: Colors.white,
                ),
                onPressed: () => addToCart(menu),
                icon: const Icon(Icons.add, size: 18),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildBottomNavigation() {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Color(0xFFEDE5DC))),
        ),
        child: Row(
          children: [
            buildNavItem(0, Icons.home_outlined, 'Home'),
            buildNavItem(1, Icons.favorite_border, 'Favorite'),
            buildNavItem(
              2,
              Icons.shopping_cart_outlined,
              'Cart',
              badge: cartCount,
            ),
            buildNavItem(3, Icons.person_outline, 'Profile'),
          ],
        ),
      ),
    );
  }

  Widget buildNavItem(int index, IconData icon, String label, {int badge = 0}) {
    final selected = selectedNavIndex == index;

    return Expanded(
      child: InkWell(
        onTap: () {
          setState(() => selectedNavIndex = index);
        },
        borderRadius: BorderRadius.circular(15),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 13,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: selected ? beige : Colors.transparent,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Icon(icon, size: 19, color: selected ? brown : muted),
                ),
                if (badge > 0)
                  Positioned(
                    right: 3,
                    top: -4,
                    child: Container(
                      padding: const EdgeInsets.all(3),
                      decoration: const BoxDecoration(
                        color: brown,
                        shape: BoxShape.circle,
                      ),
                      child: Text(
                        '$badge',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 8,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                fontSize: 9,
                color: selected ? brown : muted,
                fontWeight: selected ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildCartPage() {
    final items = cartMenus;

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 20, 18, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Keranjang Saya',
            style: TextStyle(
              fontSize: 23,
              fontWeight: FontWeight.bold,
              fontFamily: 'serif',
              color: brown,
            ),
          ),

          const SizedBox(height: 5),

          const Text(
            'Periksa kembali pesanan favoritmu.',
            style: TextStyle(fontSize: 12, color: muted),
          ),

          const SizedBox(height: 20),

          Expanded(
            child: items.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.shopping_bag_outlined,
                          size: 65,
                          color: muted,
                        ),
                        const SizedBox(height: 14),
                        const Text(
                          'Keranjang masih kosong',
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                            color: brown,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Yuk, pilih menu favoritmu!',
                          style: TextStyle(color: muted),
                        ),
                        const SizedBox(height: 20),
                        FilledButton(
                          style: FilledButton.styleFrom(
                            backgroundColor: brown,
                            foregroundColor: Colors.white,
                          ),
                          onPressed: () {
                            setState(() {
                              selectedNavIndex = 0;
                            });
                          },
                          child: const Text('Lihat Menu'),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: items.length,
                    itemBuilder: (context, index) {
                      final menu = items[index];
                      final quantity = cart[menu.nama] ?? 0;

                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        color: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Row(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.asset(
                                  menu.gambar,
                                  width: 75,
                                  height: 75,
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) {
                                    return Container(
                                      width: 75,
                                      height: 75,
                                      color: beige,
                                      child: const Icon(
                                        Icons.restaurant,
                                        color: brown,
                                      ),
                                    );
                                  },
                                ),
                              ),

                              const SizedBox(width: 12),

                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      menu.nama,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13,
                                        color: brown,
                                      ),
                                    ),
                                    const SizedBox(height: 5),
                                    Text(
                                      displayCategory(menu),
                                      style: const TextStyle(
                                        color: muted,
                                        fontSize: 10,
                                      ),
                                    ),
                                    const SizedBox(height: 5),
                                    Text(
                                      formatHarga(menu.harga),
                                      style: const TextStyle(
                                        color: brown,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              Column(
                                children: [
                                  IconButton(
                                    visualDensity: VisualDensity.compact,
                                    onPressed: () {
                                      updateCartQuantity(menu, -1);
                                    },
                                    icon: const Icon(
                                      Icons.remove_circle_outline,
                                      color: brown,
                                    ),
                                  ),
                                  Text(
                                    '$quantity',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: brown,
                                    ),
                                  ),
                                  IconButton(
                                    visualDensity: VisualDensity.compact,
                                    onPressed: () {
                                      updateCartQuantity(menu, 1);
                                    },
                                    icon: const Icon(
                                      Icons.add_circle_outline,
                                      color: brown,
                                    ),
                                  ),
                                ],
                              ),

                              IconButton(
                                visualDensity: VisualDensity.compact,
                                onPressed: () {
                                  setState(() {
                                    cart.remove(menu.nama);
                                  });
                                },
                                icon: const Icon(
                                  Icons.delete_outline,
                                  color: Colors.redAccent,
                                  size: 19,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),

          if (items.isNotEmpty) ...[
            // RINGKASAN PESANAN
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Subtotal', style: TextStyle(color: muted)),
                      Text(
                        formatHarga(cartSubtotal),
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: brown,
                        ),
                      ),
                    ],
                  ),

                  if (hasUnpricedItems) ...[
                    const SizedBox(height: 8),
                    const Text(
                      'Beberapa menu belum memiliki harga. '
                      'Total akhir belum dapat dihitung.',
                      style: TextStyle(fontSize: 10, color: Colors.redAccent),
                    ),
                  ],

                  const Divider(height: 24),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Total sementara',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: brown,
                        ),
                      ),
                      Text(
                        formatHarga(cartSubtotal),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: brown,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        backgroundColor: brown,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        goToPayment();
                      },
                      child: const Text(
                        'Lanjut ke Pembayaran',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class CategoryHeaderDelegate extends SliverPersistentHeaderDelegate {
  final List<String> categories;
  final String selectedCategory;
  final Color background;
  final Color beige;
  final Color brown;
  final ValueChanged<String> onCategorySelected;

  const CategoryHeaderDelegate({
    required this.categories,
    required this.selectedCategory,
    required this.background,
    required this.beige,
    required this.brown,
    required this.onCategorySelected,
  });

  @override
  double get minExtent => 58;

  @override
  double get maxExtent => 58;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return Container(
      color: background,
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          child: Row(
            children: categories.map((category) {
              final isSelected = category == selectedCategory;

              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(category),
                  selected: isSelected,
                  onSelected: (_) => onCategorySelected(category),
                  showCheckmark: false,
                  backgroundColor: Colors.white,
                  selectedColor: brown,
                  side: BorderSide(color: isSelected ? brown : beige),
                  shape: const StadiumBorder(),
                  labelStyle: TextStyle(
                    color: isSelected ? Colors.white : brown,
                    fontSize: 12,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 2,
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  @override
  bool shouldRebuild(covariant CategoryHeaderDelegate oldDelegate) {
    return oldDelegate.selectedCategory != selectedCategory ||
        oldDelegate.background != background ||
        oldDelegate.beige != beige ||
        oldDelegate.brown != brown ||
        oldDelegate.categories != categories ||
        oldDelegate.onCategorySelected != onCategorySelected;
  }
}
