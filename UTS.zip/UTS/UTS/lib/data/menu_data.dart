
import '../models/menu.dart';

const List<Menu> daftarMenu = [
  // MAKANAN
  Menu(
    nama: 'Nasi Goreng',
    kategori: 'Makanan',
    harga: 23000,
    deskripsi: 'Nasi goreng dengan bumbu khas dan rasa lezat.',
    gambar: 'assets/menu/nasi_goreng.jpeg',
  ),
  Menu(
    nama: 'Steak Sapi',
    kategori: 'Makanan',
    harga: 35000,
    deskripsi: 'Steak daging sapi dengan sajian istimewa.',
    gambar: 'assets/menu/steak_sapi.jpeg',
  ),
  Menu(
    nama: 'Kentang Goreng',
    kategori: 'Makanan',
    harga: 10000,
    deskripsi: 'Kentang goreng renyah dan gurih.',
    gambar: 'assets/menu/kentang_goreng.jpeg',
  ),

  // PASTRY & DESSERT
  Menu(
    nama: 'Pastry',
    kategori: 'Pastry & Dessert',
    harga: 15000,
    deskripsi: 'Pastry dengan tekstur lembut dan renyah.',
    gambar: 'assets/menu/pastry.jpeg',
  ),
  Menu(
    nama: 'Bolu Pisang',
    kategori: 'Pastry & Dessert',
    harga: 12000,
    deskripsi: 'Bolu pisang lembut dengan aroma pisang.',
    gambar: 'assets/menu/bolu_pisang.jpeg',
  ),
  Menu(
    nama: 'Kukis',
    kategori: 'Pastry & Dessert',
    harga: 10000,
    deskripsi: 'Kukis renyah dengan cita rasa manis.',
    gambar: 'assets/menu/kukis.jpeg',
  ),
  Menu(
    nama: 'Dessert',
    kategori: 'Pastry & Dessert',
    harga: 15000,
    deskripsi: 'Hidangan penutup dengan rasa istimewa.',
    gambar: 'assets/menu/dessert.jpeg',
  ),
  Menu(
    nama: 'Cheesecake',
    kategori: 'Pastry & Dessert',
    harga: 25000,
    deskripsi: 'Kue keju lembut dengan rasa creamy.',
    gambar: 'assets/menu/cheesecake.jpeg',
  ),

  // MINUMAN
  Menu(
    nama: 'Smoothies Alpukat',
    kategori: 'Minuman',
    harga: 20000,
    deskripsi: 'Smoothies alpukat segar dan creamy.',
    gambar: 'assets/menu/smoothies_alpukat.jpeg',
  ),
  Menu(
    nama: 'Smoothies Strawberry',
    kategori: 'Minuman',
    harga: 20000,
    deskripsi: 'Smoothies strawberry dengan rasa buah segar.',
    gambar: 'assets/menu/smoothies_strawberry.jpeg',
  ),
  Menu(
    nama: 'Es Teh',
    kategori: 'Minuman',
    harga: 8000,
    deskripsi: 'Teh dingin yang menyegarkan.',
    gambar: 'assets/menu/es_teh.jpeg',
  ),
  Menu(
    nama: 'Lemon Tea',
    kategori: 'Minuman',
    harga: 10000,
    deskripsi: 'Perpaduan teh dan lemon yang menyegarkan.',
    gambar: 'assets/menu/lemon_tea.jpeg',
  ),
  Menu(
    nama: 'Milkshake Taro',
    kategori: 'Minuman',
    harga: 15000,
    deskripsi: 'Milkshake taro dengan tekstur creamy.',
    gambar: 'assets/menu/milkshake_taro.jpeg',
  ),
  Menu(
    nama: 'Milk Tea',
    kategori: 'Minuman',
    harga: 15000,
    deskripsi: 'Perpaduan teh dan susu yang nikmat.',
    gambar: 'assets/menu/milk_tea.jpeg',
  ),
  Menu(
    nama: 'Milkshake Cokelat',
    kategori: 'Minuman',
    harga: 15000,
    deskripsi: 'Milkshake cokelat dengan rasa manis.',
    gambar: 'assets/menu/milkshake_cokelat.jpeg',
  ),
  Menu(
    nama: 'Kopi Gula Aren',
    kategori: 'Minuman',
    harga: 15000,
    deskripsi: 'Kopi susu dengan manis khas gula aren.',
    gambar: 'assets/menu/kopi_gula_aren.jpeg',
  ),
  Menu(
    nama: 'Matcha',
    kategori: 'Minuman',
    harga: 20000,
    deskripsi: 'Minuman matcha dengan rasa khas teh hijau.',
    gambar: 'assets/menu/matcha.jpeg',
  ),
  Menu(
    nama: 'Air Mineral',
    kategori: 'Minuman',
    harga: 7000,
    deskripsi: 'Air mineral segar dan menyegarkan.',
    gambar: 'assets/menu/air_mineral.jpeg',
  ),
];
