
import 'package:flutter_test/flutter_test.dart';
import 'package:material_ui/material_ui.dart';
import 'package:praktikum_interaktif/screens/home_page.dart';

void main() {
  testWidgets('Dashboard CUTAKK tampil dengan benar',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: HomePage(),
      ),
    );

    expect(find.text('Mau pesan apa hari ini?'), findsOneWidget);
    expect(find.text('Pilihan untukmu'), findsOneWidget);
    expect(find.text('17 menu'), findsOneWidget);
  });
}
